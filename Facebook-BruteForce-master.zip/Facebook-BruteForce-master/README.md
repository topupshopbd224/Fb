# Facebook-BruteForce
```
Bruteforce attack, For educational purpose only
```
## Find here a video on YouTube
https://youtu.be/qIfGxDmRQIU

## Install Requirements (on Linux)
```
>> apt-get install git python3 python3-pip python python-pip
```

## Run commands one by one
```
>> git clone https://github.com/IAmBlackHacker/Facebook-BruteForce
>> cd Facebook-BruteForce
>> python3 -m pip install requests bs4
>> python3 -m pip install mechanize
>> python3 fb.py or python fb2.py
```

## Screenshots
![CAPTURE 1](https://github.com/IAmBlackHacker/Facebook-BruteForce/blob/master/Screenshots/Capture1.JPG)
![CAPTURE 1](https://github.com/IAmBlackHacker/Facebook-BruteForce/blob/master/Screenshots/Capture2.JPG)
![CAPTURE 1](https://github.com/IAmBlackHacker/Facebook-BruteForce/blob/master/Screenshots/Capture3.JPG)

## Protection Against Attacker
* Use Strong Password(which contains standard password chars + longest as possible)
* Use 2F Authentication.
* Make location based login(+browser based).

## Explore More in Hacking ...
https://www.facebook.com/B14CKH4K3R/

~~~
Happy Hacking Day !
~~~
